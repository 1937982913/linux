tac
===

将文件以行为单位的反序输出

## 补充说明

**tac命令** 用于将文件以行为单位的反序输出，即第一行最后显示，最后一行先显示。

###  语法 

```shell
tac(选项)(参数)
```

###  选项 

```shell
-a或——append：将内容追加到文件的末尾；
-i或——ignore-interrupts：忽略中断信号。
```

###  参数 

文件列表：指定要保存内容的文件列表。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->
