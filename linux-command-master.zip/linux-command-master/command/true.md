true
===

返回状态为成功。

## 概要

```shell
true
```

## 主要用途

- 用于和其他命令进行逻辑运算。

## 返回值

返回状态总是成功；返回值为0。

## 例子

```shell
# 当你的脚本设置set -e时，任何返回值为失败的命令都会使得脚本退出。
set -e
# 如何临时跳过呢？下面的语句使用逻辑或操作符连接true，返回值一定为真。
some_command || true

# 当然，和python的pass一样，也可以用作条件语句临时占位。
```


### 注意

1. 该命令是bash内建命令，相关的帮助信息请查看`help`命令。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->
