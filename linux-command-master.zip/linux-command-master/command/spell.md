spell
===

对文件进行拼写检查

## 补充说明

**spell命令** 对文件进行拼写检查，并把拼写错误的单词输出。

###  语法

```shell
spell(参数)
```

###  参数

文件：指定需要进行拼写检查的文件。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->