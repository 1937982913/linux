ifup
===

激活指定的网络接口

## 补充说明

**ifup命令** 用于激活指定的网络接口。

###  语法

```shell
ifup(参数)
```

###  参数

网络接口：要激活的网络接口。

###  实例

```shell
ifup eth0   #激活eth0
```


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->