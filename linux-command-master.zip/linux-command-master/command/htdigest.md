htdigest
===

Apache服务器内置工具

## 补充说明

**htdigest命令** 是Apache的Web服务器内置工具，用于创建和更新储存用户名、域和用于摘要认证的密码文件。

###  语法

```shell
htdigest(选项)(参数)
```

###  选项

```shell
-c：创建密码文件。
```

###  参数

*   密码文件：指定要创建或更新的密码文件；
*   域：指定用户名所属的域；
*   用户名：要创建或者更新的用户名。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->