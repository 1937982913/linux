arj
===

用于创建和管理.arj压缩包

## 补充说明

**arj命令** 是 `.arj` 格式的压缩文件的管理器，用于创建和管理 `.arj` 压缩包。

###  语法

```shell
arj(参数)
```

###  参数

*  操作指令：对  `.arj` 压缩包执行的操作指令；
*  压缩包名称：指定要操作的arj压缩包名称。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->