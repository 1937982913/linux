bzless
===

增强.bz2压缩包查看器

## 补充说明

**bzless命令** 是增强“.bz2”压缩包查看器，bzless比bzmore命令功能更加强大。

###  语法

```shell
bzless(参数)
```

###  参数

文件：指定要分屏显示的.bz2压缩包。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->