squid
===

squid服务器守护进程

## 补充说明

**squid命令** 高性能的Web客户端代理缓存服务器套件“squid”的服务器守护进程。

###  语法

```shell
squid(选项)
```

###  选项

```shell
-d：将指定调试等级的信息发送到标准错误设备；
-f：使用指定的配置文件。而不使用默认配置文件；
-k：向squid服务器发送指令；
-s：启用syslog日志；
-z：创建缓存目录；
-C：不捕获致命信号；
-D：不进行DNS参数测试；
-N：以非守护进程模式运行；
-X：强制进入完全调试模式。
```


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->