logname
===

用来显示用户名称

## 补充说明

**logname命令** 用来显示用户名称。

###  语法

```shell
logname(选项)
```

###  选项

```shell
--help：在线帮助；
--vesion：显示版本信息。
```


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->