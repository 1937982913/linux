clear
===

清除当前屏幕终端上的任何信息

## 补充说明

**clear命令** 用于清除当前屏幕终端上的任何信息。

###  语法

```shell
clear
```

###  实例

直接输入clear命令当前终端上的任何信息就可被清除。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->