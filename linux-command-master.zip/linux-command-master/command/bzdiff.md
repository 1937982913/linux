bzdiff
===

直接比较两个.bz2压缩包中文件的不同

## 补充说明

**bzdiff命令** 用于直接比较两个“.bz2”压缩包中文件的不同，省去了解压缩后再调用diff命令的过程。

###  语法

```shell
bzdiff(参数)
```

###  参数

*   文件1：指定要比较的第一个.bz2压缩包；
*   文件2：指定要比较的第二个.bz2压缩包。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->