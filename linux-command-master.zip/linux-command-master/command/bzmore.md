bzmore
===

查看bzip2压缩过的文本文件的内容

## 补充说明

**bzmore命令** 用于查看bzip2压缩过的文本文件的内容，当下一屏显示不下时可以实现分屏显示。

###  语法

```shell
bzmore(参数)
```

###  参数

文件：指定要分屏显示的.bz2压缩包。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->