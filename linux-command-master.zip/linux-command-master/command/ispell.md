ispell
===

检查文件中出现的拼写错误

## 补充说明

**ispell命令** 用于检查文件中出现的拼写错误。

###  语法

```shell
ispell(参数)
```

###  参数

文件：指定要进行拼写检查的文件。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->